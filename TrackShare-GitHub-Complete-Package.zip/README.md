# TrackShare Android

This is a native Android Studio project for a consent-based location-sharing app.

## Build the APK from your phone using GitHub

1. Create a GitHub repository.
2. Upload the contents of this project to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build TrackShare APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the **TrackShare-debug-apk** artifact.
8. Extract the downloaded artifact and install the APK on your Android phone.

The included GitHub Actions workflow uses Java 17 and Gradle 8.9 on GitHub's hosted Linux runner. It builds `app-debug.apk` and uploads it as a workflow artifact.

## Privacy
The app requests Android location permission only after the user taps Share My Location.
It does not implement hidden tracking, permission bypasses, or covert collection.

This starter displays the device's current coordinates locally. It does not transmit coordinates to a server.
