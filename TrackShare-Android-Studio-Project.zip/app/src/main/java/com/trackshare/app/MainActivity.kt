package com.trackshare.app

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.location.LocationListener
import android.location.LocationManager

class MainActivity : AppCompatActivity() {

    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var statusText: TextView
    private lateinit var locationText: TextView

    private var locationManager: LocationManager? = null
    private var sharing = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (granted) startLocationSharing()
            else {
                statusText.text = "Location permission was denied."
                stopSharing()
            }
        }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            locationText.text =
                "Lat: %.5f\nLon: %.5f\nAccuracy: ±%dm".format(
                    location.latitude,
                    location.longitude,
                    location.accuracy.toInt()
                )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        statusText = findViewById(R.id.statusText)
        locationText = findViewById(R.id.locationText)

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        startButton.setOnClickListener { requestLocationPermission() }
        stopButton.setOnClickListener { stopSharing() }
    }

    private fun requestLocationPermission() {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    private fun startLocationSharing() {
        if (!hasLocationPermission()) return

        try {
            locationManager?.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                5000L,
                5f,
                listener
            )
            locationManager?.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER,
                5000L,
                5f,
                listener
            )

            sharing = true
            startButton.isEnabled = false
            stopButton.isEnabled = true
            statusText.text = "Location sharing is active on this device."
        } catch (e: SecurityException) {
            statusText.text = "Unable to access location."
            stopSharing()
        }
    }

    private fun stopSharing() {
        try {
            locationManager?.removeUpdates(listener)
        } catch (_: SecurityException) {}

        sharing = false
        startButton.isEnabled = true
        stopButton.isEnabled = false
        statusText.text = "Location sharing is off."
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onDestroy() {
        stopSharing()
        super.onDestroy()
    }
}
