# TrackShare Android

Android Studio project for a consent-based location-sharing app.

## Build
Open this folder in Android Studio, allow Gradle sync, then use:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk

## Privacy
The app requests Android location permission only after the user taps Share My Location.
It does not implement hidden tracking, permission bypasses, or covert collection.

This starter displays the device's current coordinates locally. It does not transmit coordinates to a server.
